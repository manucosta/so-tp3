#ifndef	_CONTROL_H
#define	_CONTROL_H

#define	ID_PROC_CONTROL	0
#define	TAG_CONTROL	10

/* Funci�n que controla al resto de los procesos.
 * Recibe la cantidad total.
 */
void control(unsigned int np);

#endif	/* CONTROL_H */
